package uz.sdmsys.birzum.driver

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notif {
    const val CH_ALARM = "order_alarm_v3"        // ovozli (xizmat ishga tushmasa, shu kanal ovoz chiqaradi)
    const val CH_ALARM_FG = "order_alarm_fg_v1"  // ovozsiz: ovozni AlarmService o'zi chaladi
    const val CH_INFO = "info_v1"
    const val CH_TRACK = "tracking_v1"

    const val ID_ALARM = 1001
    const val ID_TRACK = 1002
    const val ID_INFO = 1003

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val sound = Uri.parse("android.resource://" + ctx.packageName + "/" + R.raw.alarm)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val alarm = NotificationChannel(CH_ALARM, ctx.getString(R.string.ch_alarm), NotificationManager.IMPORTANCE_HIGH)
        alarm.description = ctx.getString(R.string.ch_alarm_h)
        alarm.setSound(sound, attrs)
        alarm.enableVibration(true)
        alarm.vibrationPattern = longArrayOf(0, 250, 200, 250)
        alarm.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        alarm.setShowBadge(true)

        val alarmFg = NotificationChannel(CH_ALARM_FG, ctx.getString(R.string.ch_alarm_fg), NotificationManager.IMPORTANCE_HIGH)
        alarmFg.setSound(null, null)
        alarmFg.enableVibration(false)
        alarmFg.lockscreenVisibility = Notification.VISIBILITY_PUBLIC

        val info = NotificationChannel(CH_INFO, ctx.getString(R.string.ch_info), NotificationManager.IMPORTANCE_DEFAULT)
        val track = NotificationChannel(CH_TRACK, ctx.getString(R.string.ch_track), NotificationManager.IMPORTANCE_LOW)
        track.setShowBadge(false)

        // eski kanal (keskin sirena bilan) o'chiriladi: Android kanal ovozini keyin o'zgartirishga ruxsat bermaydi
        try { nm.deleteNotificationChannel("order_alarm_v2") } catch (e: Exception) { }
        nm.createNotificationChannels(listOf(alarm, alarmFg, info, track))
    }

    fun openIntent(ctx: Context, fromAlarm: Boolean): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("from_alarm", fromAlarm)
        return PendingIntent.getActivity(
            ctx, if (fromAlarm) 1 else 2, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** foreground=true: AlarmService ichidagi doimiy bildirishnoma (ovozsiz, ovozni xizmat chaladi) */
    fun alarm(ctx: Context, title: String, body: String, foreground: Boolean): Notification {
        val stop = PendingIntent.getService(
            ctx, 3,
            Intent(ctx, AlarmService::class.java).setAction(AlarmService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val open = openIntent(ctx, true)
        val b = NotificationCompat.Builder(ctx, if (foreground) CH_ALARM_FG else CH_ALARM)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setOngoing(foreground)
            .setAutoCancel(!foreground)
        if (foreground) b.addAction(0, ctx.getString(R.string.mute), stop)
        b.addAction(0, ctx.getString(R.string.open), open)
        val n = b.build()
        // Zaxira holat (fon xizmatiga ruxsat berilmasa): ovoz haydovchi ochmaguncha takrorlanadi
        if (!foreground) n.flags = n.flags or Notification.FLAG_INSISTENT
        return n
    }

    fun tracking(ctx: Context): Notification =
        NotificationCompat.Builder(ctx, CH_TRACK)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(ctx.getString(R.string.track_title))
            .setContentText(ctx.getString(R.string.track_text))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openIntent(ctx, false))
            .build()

    @SuppressLint("MissingPermission")
    fun notify(ctx: Context, id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: Exception) {
            // bildirishnoma ruxsati yo'q
        }
    }

    fun info(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_INFO)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openIntent(ctx, false))
            .build()
        notify(ctx, ID_INFO, n)
    }
}
