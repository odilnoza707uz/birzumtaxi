package uz.sdmsys.birzum.driver

import android.content.Context

object Alarm {
    /** Baland signal: avval fon xizmati (to'xtovsiz takrorlanadi); bo'lmasa — ovozli bildirishnoma */
    fun trigger(ctx: Context, title: String, body: String) {
        try {
            AlarmService.start(ctx, title, body)
        } catch (e: Exception) {
            Notif.notify(ctx, Notif.ID_ALARM, Notif.alarm(ctx, title, body, foreground = false))
        }
    }
}
